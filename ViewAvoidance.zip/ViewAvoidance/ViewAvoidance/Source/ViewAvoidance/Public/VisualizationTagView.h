﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include <Components/WidgetComponent.h>
#include "DrawDebugHelpers.h"
#include "VisualizationTagView.generated.h"

UCLASS()
class VIEWAVOIDANCE_API AVisualizationTagView : public AActor
{
	GENERATED_BODY()
	
public:	
	// 显示框图（调试用）
	bool bShowDebugLine;

	// 视图的尺寸
	FVector2D WidgetSize = FVector2D(0.f, 0.f);

	// 中心点相对位置 左上角为原点
	FVector2D PivotOff = FVector2D(0.5, 1.0);

	// 头部标签占比
	float HeadRatio;

	// 要控制的视图actor的指针
	AActor* ViewActor;

	// 视图被遮挡时倾向于的移动方向，需要归一化
	FVector PreferMoveDircetion;

	// widget组件
	UWidgetComponent* WidgetComponent;

	// 以TempLocation为中心的用于占位的矩形框（里面包含左上角坐标、向右/下的向量）
	TArray<FVector> TempBox;

	// 物理引用的空间位置
	FVector PhysicalReferenceLocation;

	// 视图中心位置（在显示线条时为向上100像素，不显示线条时为物理参考点）
	FVector ViewCenterLocation;

	// Sets default values for this actor's properties
	AVisualizationTagView();

	// 初始化
	void init(AActor* Actor, UWidgetComponent* widgetComponent);

	// 计算与视图-用户-参考点角度
	float CalculateViewUserPhyAngle(FVector ViewPosition, FVector UserPosition);

	// 计算与视图-用户-参考点角度相关的力导向能量，角度越大，能量越大
	float CalculateForceDirectedEnergy(FVector UserPosition);
	// 计算视图的遮挡能量，遮挡程度越大，能量越大
	float CalculateOcclusionEnergy(FVector ViewPosition, FVector UserPosition, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance);

	// 返回视图是否被遮挡（遮挡率大于0）
	bool IsViewOccluded();
	// 获取视图遮挡率
	float GetOcclusionRate();

	// 用于设置动画移动的目的地，并立即开始播放
	void MoveToDestination(FVector Destination);
	// 用于设置迭代过程中的位置TempLocation，和占位盒TempBox
	void SetTempLocation(FVector position);
	// 获取迭代中的位置
	FVector GetTempLocation();
	// 设置视图实际的位置，只在初始化时调用，后续由MoveSmoothlyToLocation函数自动修改
	void SetCurrentLocation(FVector position);

	// 设置是否绘制Line，会设置ViewCenterLocation
	void SetShowViewLine(bool flag);
	// 设置连线颜色
	void SetLineColor(FColor color);
	// 设置连线宽度
	void SetLineWidth(float width);
	
	

	// 根据获取到的采样点来得到采样率
	float UpdateOcclusionRate(FVector ViewPosition, FVector UserPosition, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance);

	// 更新占位盒
	// float UpdateTempBox(FVector Location);
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

private:
	// 视图是否被遮挡（遮挡率大于0）
	bool IsOccluded = true;
	// 当前视图对象的遮挡率
	float OcclusionRate = 0.0f;

	// 视图每一帧中实际显示的位置
	FVector CurrentLocation;
	// 迭代过程的位置
	FVector TempLocation;
	// 视图动画移动的目的地
	FVector MoveDestination;
	
	UWidgetComponent* VisualizationWidget;
	UStaticMeshComponent* VisualizationMesh;

	// 用于平滑移动的计数
	int MoveTimes = 0;
	// 期望移动在MaxMoveTimes次后结束
	int MaxMoveTimes = 100;

	// 显示连线
	bool bShowLine;
	// 连线颜色
	FColor LineColor;
	// 连线宽度
	float LineWidth;

	// 用于存储射采样点的数组
	TArray<FVector> SamplePoints;

	// 缓慢移动视图
	void MoveSmoothlyToLocation();
	// 更新视图的绘制大小，需要不断更新
	void UpdateWidgetSize();

	// 投射光线，接收光线起点和终点，所有需要移动的视图
	// 如果光线被遮挡返回true，反之返回false
	bool PerformSingleRaycast(const FVector& Start, const FVector& End, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance);

	// 设置参考点与视图的连线（默认在视图中心）
	void DrawLine();
	// 获取视图采样点位置
	void GetSamplePoints(FVector Location);

	// 用来算行列式的
	float DeterminantFor3x3(FVector a, FVector b, FVector c);

	// 显示框图
	void ShowDebugLine();
};
