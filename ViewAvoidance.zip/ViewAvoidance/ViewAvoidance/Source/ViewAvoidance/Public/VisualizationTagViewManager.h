﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/WidgetComponent.h"
#include "EngineUtils.h"
#include "VisualizationTagView.h"
#include "Kismet/GameplayStatics.h"
#include "VisualizationTagViewManager.generated.h"

UCLASS()
class VIEWAVOIDANCE_API AVisualizationTagViewManager : public AActor
{
	GENERATED_BODY()
	
public:
	// Sets default values for this actor's properties
	AVisualizationTagViewManager();

	// 存储所有视图对象的列表
	TArray<AVisualizationTagView*> VisualizationTagViews;

	// 当前在视角中并且存在被遮挡情况的视图对象
	TArray<AVisualizationTagView*> NeedMoveTagViews;

	// 要调整的Actor标签
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	FName TagName = "Label";

	// 最大可视距离
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	float MaxViewDistance = 1e5;

	// Actor头部(避让的部分)占比
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization",meta = (ClampMin = "0.0", ClampMax = "1.0", UIMin = "0.0", UIMax = "1.0"))
	float HeadRatio = 0.4;

	// 锚点偏移量(左上角为原点)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	FVector2D PivotOff = FVector2D(0.5, 1.0);

	// 显示视图与参考点间的连线
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	bool bShowLine = false;

	// 绘制的线条颜色
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	FColor LineColor = FColor(200, 200, 200, 200);

	// 绘制的线条宽度
	//UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	float LineWidth = 10.f;

	// 是否开启算法
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	bool IsSimulated = true;

	// 竖直方向允许的最大位移
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	float MoveAmplitude = 4000.f;

	// 显示调试框
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visualization")
	bool bShowDebugLine = false;

	// 模拟退火算法参数（可通过编辑器或运行时修改）
	// 初始温度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Simulated Annealing", meta = (ClampMin = "0.0", UIMin = "0.0"))
	float InitialTemperature = 1000.0f;
	// 冷却率
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Simulated Annealing", meta = (ClampMin = "0.0", ClampMax = "1.0", UIMin = "0.0", UIMax = "1.0"))
	float CoolingRate = 0.8f;
	// 最小温度
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Simulated Annealing", meta = (ClampMin = "0.0", UIMin = "0.0"))
	float MinTemperature = 1.0f;
	// 最大迭代次数
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Simulated Annealing", meta = (ClampMin = "1", UIMin = "1"))
	int32 MaxIterations = 70;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

private:
	// 上一次使用的线条宽度
	float LastLineWidth;
	// 上一次使用的头占比
	float LastHeadRatio;
	// 上一次使用的中心点相对位置
	FVector2D LastPivotOff;
	// 上一次使用的线条颜色
	FColor LastLineColor;
	// 上次设置的是否启用模拟
	bool bLastIsSimulated;
	// 上一次设置的是否显示连线
	bool bLastShowLine;
	// 上一次使用的TagName
	FName LastTag = "";
	// 上一次设置的是否显示框图
	bool bLastShowDebugLine;
	// 算法迭代次数
	int32 CurrentIteration;
	// 布局当前的能量
	float CurrentEnergy;
	// 调整布局之前的能量
	float LastEnergy;
	// 算法当前温度
	float CurrentTemperature;

	// 视点（用户）位置，需要每帧更新
	FVector UserLocation;
	// 视角（用户）旋转，需要每帧更新
	FRotator UserRotation;
	// 上一次记录的用户位置
	FVector LastUserPosition = FVector::ZeroVector;
	// 上一次记录的用户角度
	FRotator LastUserRotation = FRotator::ZeroRotator;

	// 获取所有带指定Tag的视图，需要运行时更新
	void GetViewsWithTag(const FName& Tag);

	// 更新需要移动的带指定Tag的视图，需要每帧更新
	void UpdateNeedMoveTagViews();

	// 计算当前布局的能量（成本）的函数
	float CalculateLayoutEnergy();

	// 获取一个随机视图
	AVisualizationTagView* GetRandomView();

	// 计算移动方向+随机扰动
	FVector CalculateDisplacementDirection(AVisualizationTagView* View);

	// 计算移动距离
	float CalculateDisplacementDistance(AVisualizationTagView* View);

	// 判断是否接受新状态
	bool ShouldAcceptNewState(float DeltaE);

	// 模拟退火的单次迭代，每次迭代在Tick中进行
	void PerformOneIteration();
};
