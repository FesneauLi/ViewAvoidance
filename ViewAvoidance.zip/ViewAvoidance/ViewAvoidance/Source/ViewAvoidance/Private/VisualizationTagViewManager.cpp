﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "VisualizationTagViewManager.h"

AVisualizationTagViewManager::AVisualizationTagViewManager()
{
    // Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AVisualizationTagViewManager::BeginPlay()
{
    Super::BeginPlay();
}

// Called every frame
void AVisualizationTagViewManager::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // 指示是否需要初始化迭代条件
    bool flag = false;

    // TagName是否发生改变
    if (TagName != LastTag) {
        flag = flag || true;


        // 带之前Tag的视图重置回起点
        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->ViewActor->SetActorLocation(View->ViewCenterLocation);
            View->Destroy();
        }

        GetViewsWithTag(TagName);

        LastTag = TagName;
    }

    // 是否刚开启/关闭模拟退火算法
    if (bLastIsSimulated != IsSimulated) {
        if (IsSimulated) {
            flag = flag || true;
        }
        else {
            // 全部重置回起点去
            for (AVisualizationTagView* View : VisualizationTagViews) {
                View->MoveToDestination(View->ViewCenterLocation);
                View->SetTempLocation(View->ViewCenterLocation);
            }
        }
        bLastIsSimulated = IsSimulated;
    }

    // 每一帧获取用户位置
    if (APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0))
    {
        PC->GetPlayerViewPoint(UserLocation, UserRotation);

        // 视点位置是否发生改变
        if (!LastUserPosition.Equals(UserLocation, KINDA_SMALL_NUMBER)) {
            flag = flag || true;
            LastUserPosition = UserLocation;
        }
    }

    // 是否绘制视图到物体的连线
    if (bShowLine != bLastShowLine) {

        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->SetShowViewLine(bShowLine);
        }

        bLastShowLine = bShowLine;
    }

    // 更改了连线的颜色
    if (LineColor != LastLineColor) {
        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->SetLineColor(LineColor);
        }

        LastLineColor = LineColor;
    }

    // 更改了连线的宽度
    if (LineWidth != LastLineWidth) {

        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->SetLineWidth(LineWidth);
        }

        LastLineWidth = LineWidth;
    }

    // 更改了头占比
    if (HeadRatio != LastHeadRatio) {

        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->HeadRatio = HeadRatio;
        }

        LastHeadRatio = HeadRatio;
    }
    // 更改中心点相对位置 左上角为原点
    if (!PivotOff.Equals(LastPivotOff, KINDA_SMALL_NUMBER)) {

        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->PivotOff = PivotOff;
        }

        LastPivotOff = PivotOff;
    }

    // 显示框图
    if (bShowDebugLine != bLastShowDebugLine) {

        for (AVisualizationTagView* View : VisualizationTagViews) {
            View->bShowDebugLine = bShowDebugLine;
        }

        bLastShowDebugLine = bShowDebugLine;
    }

    // 算法在启用且满足重置条件
    if (flag && IsSimulated) {
        // 更新需要改变的视图
        UpdateNeedMoveTagViews();

        // 这里重置迭代初始化条件
        UE_LOG(LogTemp, Log, TEXT("Initialize Temperature"));

        CurrentTemperature = InitialTemperature;
        CurrentIteration = 0;

        // 重置视图迭代起点，但是不播放动画
        for (AVisualizationTagView* View : NeedMoveTagViews) {

            // 但如果原位置过于差，那就不再移回去了，否则就重置回参考点
            if (View->UpdateOcclusionRate(View->ViewCenterLocation, UserLocation, NeedMoveTagViews, MaxViewDistance) > 0.8) {
                ;
            }
             else {
                // 重置回参考点
                View->SetTempLocation(View->ViewCenterLocation);
                View->MoveToDestination(View->ViewCenterLocation);
            }
        }
    }

    // 如果算法在启用且未满足终止条件，则执行模拟退火迭代算法
    if (IsSimulated) {

        if (CurrentTemperature > MinTemperature && CurrentIteration < MaxIterations)
        {
            PerformOneIteration();
        }
    }
}

void AVisualizationTagViewManager::GetViewsWithTag(const FName& Tag)
{
    VisualizationTagViews.Empty();
    // 遍历世界中所有的Actor
    for (TActorIterator<AActor> ActorItr(GetWorld()); ActorItr; ++ActorItr)
    {
        AActor* Actor = *ActorItr;

        // 检查Actor是否有指定标签
        if (ActorItr->Tags.Contains(Tag))
        {
            // 获取Actor的所有组件
            TSet<UActorComponent*> Components = Actor->GetComponents();
            // 遍历Actor的所有组件
            for (UActorComponent* Component : Components)
            {
                // 检查组件是否是WidgetComponent，有widget才会被添加到VisualizationTagViews中
                UWidgetComponent* widgetComponent = Cast<UWidgetComponent>(Component);
                if (widgetComponent)
                {
                    AVisualizationTagView* newactor = GetWorld()->SpawnActor<AVisualizationTagView>(AVisualizationTagView::StaticClass(), Actor->GetActorLocation(), FRotator::ZeroRotator);

                    newactor->init(Actor, widgetComponent);
                    newactor->HeadRatio = HeadRatio;

                    VisualizationTagViews.Add(newactor);
                    // 退出循环，因为我们应该只有一个WidgetComponent
                    break;
                }
            }

        }
    }
    return;
}

void AVisualizationTagViewManager::UpdateNeedMoveTagViews()
{
    NeedMoveTagViews.Empty(); // 清空当前列表

    for (AVisualizationTagView* View : VisualizationTagViews) // 所有视图的列表
    {
        if (View != nullptr) // && View->VisualizationWidget->IsVisible())
        {
            FVector ViewRootLocation = View->ViewCenterLocation;
            FVector Direction = ViewRootLocation - UserLocation;
            FVector DirectionToView = Direction.GetSafeNormal();
            FVector CameraForward = UserRotation.Vector();

            // 计算视图参考点方向与摄像机前方向的点积以及视图与相机的距离
            float DotProduct = FVector::DotProduct(CameraForward, DirectionToView);
            float Distance = Direction.Size();

            // 检查是否在视场内，并且被遮挡了
            View->UpdateOcclusionRate(View->GetTempLocation(), UserLocation, VisualizationTagViews, MaxViewDistance);
            // UE_LOG(LogTemp, Warning, TEXT("The OcclusionRate : %f"), View->GetOcclusionRate());
            if (DotProduct > 0 && Distance < MaxViewDistance && View->IsViewOccluded()) {
                // 视图在视锥内
                NeedMoveTagViews.Add(View);
            }
            // 不在就将其位置重置回参考点
            else {
                //View->TempLocation = ViewRootLocation;
                //View->ResetMoveNums();
            }
        }
    }
}

float AVisualizationTagViewManager::CalculateLayoutEnergy()
{
    float OcclusionEnergyTotal = 0.0f;
    float ForceDirectedEnergyTotal = 0.0f;

    // 遍历所有需要调整的视图
    for (AVisualizationTagView* View : NeedMoveTagViews)
    {
        if (View)
        {
            // 更新其遮挡率
            View->UpdateOcclusionRate(View->GetTempLocation(), UserLocation, NeedMoveTagViews, MaxViewDistance);

            // 计算并累加遮挡能量
            float OcclusionEnergy = View->CalculateOcclusionEnergy(View->GetTempLocation(), UserLocation, NeedMoveTagViews, MaxViewDistance);
            OcclusionEnergyTotal += OcclusionEnergy;

            // 计算并累加力导向能量，这个函数有问题CalculateForceDirectedEnergy
            float ForceDirectedEnergy = View->CalculateForceDirectedEnergy(UserLocation);
            ForceDirectedEnergyTotal += ForceDirectedEnergy;
            // UE_LOG(LogTemp, Warning, TEXT("ActorName %s, The OcclusionRate : %f, The ForceDirectedEnergy : %f"), *(View->ViewActor->GetName()), OcclusionEnergy, ForceDirectedEnergy);
        }
    }

    float LayoutEnergy = OcclusionEnergyTotal + ForceDirectedEnergyTotal;

    return LayoutEnergy;
}

AVisualizationTagView* AVisualizationTagViewManager::GetRandomView()
{
    if (NeedMoveTagViews.Num() == 0)
    {
        return nullptr; // 没有可选的视图
    }

    AVisualizationTagView* SelectedView = nullptr;
    int32 RandomIndex;

    RandomIndex = FMath::RandRange(0, NeedMoveTagViews.Num() - 1);
    SelectedView = NeedMoveTagViews[RandomIndex];

    return SelectedView; // 返回选择的视图或nullptr
}

FVector AVisualizationTagViewManager::CalculateDisplacementDirection(AVisualizationTagView* View)
{
    FVector SumDirection = FVector::ZeroVector;
    // 随机扰动
    // FVector RandomPerturbation = FMath::VRand();
    // 可能摆脱遮挡的方向
    // FVector Direction = View->PreferMoveDircetion;
    // SumDirection = RandomPerturbation * pow(View->GetOcclusionRate(), 2.f) + Direction;

    // return SumDirection.GetSafeNormal();
    //**
    //return FVector(0.f, 0.f, View->PreferMoveDircetion.Z).GetSafeNormal();
    return FVector(0.f, 0.f, 1.f).GetSafeNormal();
}

float AVisualizationTagViewManager::CalculateDisplacementDistance(AVisualizationTagView* View)
{
    // 随机移动的距离，最远为对角线的长度
    float DisplacementDistance = FMath::RandRange(
        0.0,
        View->WidgetSize.Size()
    );
    return DisplacementDistance;
}

bool AVisualizationTagViewManager::ShouldAcceptNewState(float DeltaE)
{
    if (DeltaE < 0.0f)
    {
        // 如果新状态能量更低，总是接受
        return true;
    }
    else
    {
        // 如果新状态能量更高，按概率接受
        float Probability = FMath::Exp(-DeltaE / CurrentTemperature);
        float RandomValue = FMath::RandRange(0.0f, 1.0f);
        return RandomValue < Probability;
    }
}

void AVisualizationTagViewManager::PerformOneIteration()
{
    // 随机选择一个视图
    AVisualizationTagView* SelectedView = GetRandomView();        // 修改为按照遮挡率为比重选择？
    if (SelectedView == nullptr)
    {
        // 更新算法参数
        CurrentTemperature *= CoolingRate;
        CurrentIteration++;
        return;
    }

    // 计算调整前的能量
    LastEnergy = CalculateLayoutEnergy();

    // 暂时存储调整前的位置
    FVector LastLocation = SelectedView->GetTempLocation();
    // 暂时存储之前的遮挡率，来自计算LastEnergy时
    float LastOcclusionRate = SelectedView->GetOcclusionRate();

    // 生成邻居状态（并限制其移动在距参考点两个视图对角线长度的范围内，并使其与用户的距离固定为用户到参考点的距离）
    // -------------------------------------------------------------------------------------------------------------
    // 计算位移方向（包括随机扰动）里面的遮挡率同样来自计算LastEnergy时
    FVector Direction = CalculateDisplacementDirection(SelectedView);
    // 计算移动距离
    float Distance = CalculateDisplacementDistance(SelectedView);

    // 从视图到视图原点的位移
    FVector VectorFromCenToView = SelectedView->GetTempLocation() + Direction * Distance - SelectedView->ViewCenterLocation;
    // 限制后的位移
    FVector RestrictedVectorFromCenToView;
    if (VectorFromCenToView.Z > 0.f) {
        RestrictedVectorFromCenToView =
            VectorFromCenToView.GetSafeNormal()
            * FMath::Min(VectorFromCenToView.Size(), MoveAmplitude);
    }
    else {
        //RestrictedVectorFromCenToView = SelectedView->ViewCenterLocation;
        RestrictedVectorFromCenToView = FVector::ZeroVector;
    }
    //// 相机到参考点的距离
    //float DistanceToModelReference = FVector::Dist(UserLocation, SelectedView->ViewCenterLocation);
    //// 从相机到视图新位置的方向
    //FVector DirectionFromCameraPositionToView = (RestrictedVectorFromCenToView + SelectedView->ViewCenterLocation - UserLocation).GetSafeNormal();
    //// 计算邻居状态视图位置
    //FVector NewPosition = UserLocation + DirectionFromCameraPositionToView * DistanceToModelReference;
    // -------------------------------------------------------------------------------------------------------------

    // 计算邻居状态视图位置
    FVector NewPosition = SelectedView->ViewCenterLocation + RestrictedVectorFromCenToView;
    // 应用得到的新位置
    SelectedView->SetTempLocation(NewPosition);

    // 计算邻居状态能量，计算能量差
    CurrentEnergy = CalculateLayoutEnergy();

    // 判断是否接受邻居状态（必须符合能量需求，并且遮挡率下降才接受）
    if (ShouldAcceptNewState(CurrentEnergy - LastEnergy) && LastOcclusionRate >= SelectedView->GetOcclusionRate())
    {
        // 如果接受新状态，开始播放动画
        SelectedView->MoveToDestination(NewPosition);
    }
    else {
        // 撤销位置修改，恢复修改的值
        SelectedView->SetTempLocation(LastLocation);
        CalculateLayoutEnergy();
    }

    // 更新算法参数
    CurrentTemperature *= CoolingRate;
    CurrentIteration++;
}
