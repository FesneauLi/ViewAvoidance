﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "VisualizationTagView.h"

// Sets default values
AVisualizationTagView::AVisualizationTagView()
{
    PrimaryActorTick.bCanEverTick = true;

    // 默认是没有倾向的移动方向
    PreferMoveDircetion = FVector(0.0f, 0.0f, 0.0f);

    SamplePoints.SetNum(25);       // 默认为均匀的25个点
    TempBox.SetNum(3);
}

void AVisualizationTagView::init(AActor* Actor, UWidgetComponent* widgetComponent)
{
    // 不要随意改变初始化顺序
    WidgetComponent = widgetComponent;  // SetTempLocation依赖于WidgetComponent
    ViewActor = Actor;
    UpdateWidgetSize();
    PhysicalReferenceLocation = Actor->GetActorLocation();
    SetShowViewLine(bShowLine);
    SetCurrentLocation(ViewCenterLocation);
    SetTempLocation(ViewCenterLocation);
    MoveToDestination(ViewCenterLocation);
}

// Called when the game starts or when spawned
void AVisualizationTagView::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AVisualizationTagView::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

    UpdateWidgetSize();
    // UE_LOG(LogTemp, Warning, TEXT("%s"), *(WidgetSize.ToString()));
    MoveSmoothlyToLocation();
    if (bShowLine) {
        DrawLine();
    }
    if (bShowDebugLine) {
        ShowDebugLine();
    }
}

float AVisualizationTagView::CalculateViewUserPhyAngle(FVector ViewPosition, FVector UserPosition)
{
    FVector VecA = (ViewCenterLocation - UserPosition).GetSafeNormal();
    FVector VecB = (ViewPosition - UserPosition).GetSafeNormal();
    double DotProductResult = FVector::DotProduct(VecA, VecB);
    return acos(FVector::DotProduct(VecA, VecB));
}

float AVisualizationTagView::CalculateForceDirectedEnergy(FVector UserPosition)
{
    return 200.f * CalculateViewUserPhyAngle(TempLocation, UserPosition);  // 200是为了值不会太小，范围为[0, 200 * PI]
}

float AVisualizationTagView::CalculateOcclusionEnergy(FVector ViewPosition, FVector UserPosition, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance)
{
    // 获取视图的遮挡率
    float Rate = GetOcclusionRate();
    // 计算角度因子
    float p = atan(WidgetSize.Length() / FVector::Dist(ViewCenterLocation, UserPosition));
    float DistanceFactor = 200 * p;                // 这里200是上面力导向能量里的

    // 使用距离因子调整遮挡能量
    return pow(Rate, 0.1f) * DistanceFactor;       // k1 * DrawSize.Length() / distance <= k2 * 1
}

bool AVisualizationTagView::IsViewOccluded()
{
    return IsOccluded;
}

float AVisualizationTagView::GetOcclusionRate()
{
    return OcclusionRate;
}

void AVisualizationTagView::MoveToDestination(FVector Destination)
{
    MoveTimes = 0;
    MoveDestination = Destination;
}

void AVisualizationTagView::SetTempLocation(FVector position)
{
    TempLocation = position;

    if (!WidgetComponent) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"WidgetComponent\" when \"SetTempLocation\""));
        return;
    }

    // 获取 WidgetComponent 的组件变换
    FTransform WidgetComponentTransform = WidgetComponent->GetComponentTransform();

    // 使用变换矩阵的上方和左方向量
    FVector WidgetCenterWorldPosition = WidgetComponentTransform.TransformPosition(FVector(0.f, 0.f, 0.f));
    FVector upVector = WidgetComponentTransform.TransformPosition(FVector(0.f, 0.f, WidgetSize.Y)) - WidgetCenterWorldPosition;
    FVector leftVector = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X, 0.f)) - WidgetCenterWorldPosition;

    // UE_LOG(LogTemp, Warning, TEXT("%s, %s"), *leftVector.ToString(), *upVector.ToString());

    // 计算采样点的世界坐标
    // 左上角
    //FVector LeftUpLocation = position + leftVector + upVector*2;
    FVector LeftUpLocation = position + leftVector * PivotOff.X + upVector * PivotOff.Y;
    // 更新用于占位的TempBox
    //TempBox[0] = LeftUpLocation;
    //TempBox[1] = -leftVector * 2;
    //TempBox[2] = -upVector * 2 * HeadRatio;
    TempBox[0] = LeftUpLocation;
    TempBox[1] = -leftVector;
    TempBox[2] = -upVector * HeadRatio;

    //**
   /* TempBox[0] = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, WidgetSize.Y));
    TempBox[1] = WidgetComponentTransform.TransformPosition(FVector(0.f, -WidgetSize.X / 2, WidgetSize.Y)) - LeftUpLocation;
    TempBox[2] = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, 0)) - LeftUpLocation;
    TempBox[2] *= HeadRatio;*/
}

FVector AVisualizationTagView::GetTempLocation()
{
    return TempLocation;
}

void AVisualizationTagView::SetCurrentLocation(FVector position)
{
    CurrentLocation = position;
}

void AVisualizationTagView::SetShowViewLine(bool flag)
{
    bShowLine = flag;

    if (bShowLine) {
        ViewCenterLocation = PhysicalReferenceLocation + FVector(0, 0, 100 + WidgetSize.Y / 2);
    }
    else {
        ViewCenterLocation = PhysicalReferenceLocation;
        //+FVector(0, 0, WidgetSize.Y / 2);
    }
}

void AVisualizationTagView::SetLineColor(FColor color)
{
    LineColor = color;
}

void AVisualizationTagView::SetLineWidth(float width)
{
    LineWidth = width;
}

void AVisualizationTagView::ShowDebugLine()
{
    // 获取 WidgetComponent 的组件变换
    FTransform WidgetComponentTransform = WidgetComponent->GetComponentTransform();

    // UE_LOG(LogTemp, Warning, TEXT("%s, %s"), *leftVector.ToString(), *upVector.ToString());

    // 三个角
    /*FVector LeftUpLocation = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, WidgetSize.Y));
    FVector RightVector = WidgetComponentTransform.TransformPosition(FVector(0.f, -WidgetSize.X / 2, WidgetSize.Y )) - LeftUpLocation;
    FVector DownVector = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, 0)) - LeftUpLocation;
    DownVector *= HeadRatio;*/
    // red
    // DrawDebugLine(GetWorld(), LeftUpLocation, LeftUpLocation + RightVector, FColor(255, 0, 0, 255), false, -1.0f, 0, 10.f);
    // DrawDebugLine(GetWorld(), LeftUpLocation, LeftUpLocation + DownVector, FColor(255, 0, 0, 255), false, -1.0f, 0, 10.f);
    // green
    DrawDebugLine(GetWorld(), TempBox[0], TempBox[0] + TempBox[1], FColor(0, 255, 0, 255), false, -1.0f, 0, 10.f);
    DrawDebugLine(GetWorld(), TempBox[0], TempBox[0] + TempBox[2], FColor(0, 255, 0, 255), false, -1.0f, 0, 10.f);
    DrawDebugLine(GetWorld(), TempBox[0] + TempBox[1], TempBox[0] + TempBox[1] + TempBox[2], FColor(0, 255, 0, 255), false, -1.0f, 0, 10.f);
    DrawDebugLine(GetWorld(), TempBox[0] + TempBox[2], TempBox[0] + TempBox[1] + TempBox[2], FColor(0, 255, 0, 255), false, -1.0f, 0, 10.f);
}

void AVisualizationTagView::MoveSmoothlyToLocation()
{
    if (!ViewActor) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"ViewActor\" when \"MoveSmoothlyToLocation\""));
        return;
    }

    if (MoveTimes < MaxMoveTimes) {
        MoveTimes++;                                                     // 在目标位置MoveDestination重置时会重新开始计数
        CurrentLocation += (MoveDestination - CurrentLocation) * ((float)MoveTimes / (float)MaxMoveTimes);
        ViewActor->SetActorLocation(CurrentLocation);
    }
    else {
        // 调整占位盒姿态
        SetTempLocation(TempLocation);
    }
}

void AVisualizationTagView::UpdateWidgetSize()
{
    if (!WidgetComponent) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"WidgetComponent\" when \"UpdateWidgetSize\""));
        return;
    }

    // WidgetSize = WidgetComponent->GetWidget()->GetDesiredSize();
    WidgetSize = WidgetComponent->GetCurrentDrawSize();
}

bool AVisualizationTagView::PerformSingleRaycast(const FVector& Start, const FVector& End, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance)
{
    if (!ViewActor) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"ViewActor\" when \"PerformSingleRaycast\""));
        return false;
    }

    FHitResult HitResult;  // dummy
    bool bhit = false;

    FCollisionQueryParams QueryParams;

    // 光线投射方向
    FVector CastDirection = (End - Start).GetSafeNormal();
    float CastDistance = (End - Start).Size();
    for (AVisualizationTagView* View : ViewBox) {
        // 将所有视图本体忽略
        QueryParams.AddIgnoredActor(View->ViewActor);

        // 除了选中的视图，其他视图的占位盒都拿进来
        if (View && View != this) {
            
            // o1 + r*d = o2 + m*a + n*b
            // 克莱默法则求解d, m, n
            FVector o1minuso2 = Start - View->TempBox[0];
            float D = DeterminantFor3x3(View->TempBox[1], View->TempBox[2], -CastDirection);
            float D1 = DeterminantFor3x3(o1minuso2, View->TempBox[2], -CastDirection);
            float D2 = DeterminantFor3x3(View->TempBox[1], o1minuso2, -CastDirection);
            float D3 = DeterminantFor3x3(View->TempBox[1], View->TempBox[2], o1minuso2);
            float m = D1 / D;
            float n = D2 / D;
            float d = D3 / D;
            
            // 被其他视图的占位盒挡住，直接返回
            //**
            if ((m>0 && m<1) && (n>0 && n<1) && (d>0&&d< CastDistance)) {
                return true;
            };
        }
    }

    // 与场景求交
    bhit = GetWorld()->LineTraceSingleByChannel(HitResult, Start, End, ECC_Visibility, QueryParams);

    return bhit;
}

void AVisualizationTagView::DrawLine()
{
    if (!WidgetComponent) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"WidgetComponent\" when \"Draw Line\""));
        return;
    }

    // 获取 WidgetComponent 的组件变换
    FTransform WidgetComponentTransform = WidgetComponent->GetComponentTransform();

    // 视图正下点本地坐标
    FVector LocalPosition = FVector(0, 0, -WidgetSize.Y / 2); // 本地坐标(0, 0, 0)为中心，(1, 0, 0)为前向)

    // 将其本地坐标转换为世界坐标
    FVector WorldPosition = WidgetComponentTransform.TransformPosition(LocalPosition);

    DrawDebugLine(
        GetWorld(),
        WorldPosition,
        PhysicalReferenceLocation,
        LineColor,                 // 线条颜色
        false,                     // 不持久化线条
        -1.0f,                     // 持续时间
        0,                         // DepthPriority
        LineWidth                  // 线条宽度
    );
}

// 依照传入的位置为中心，获取视图采样点位置
void AVisualizationTagView::GetSamplePoints(FVector Location)
{
    if (!WidgetComponent) {
        UE_LOG(LogTemp, Warning, TEXT("Can't find \"WidgetComponent\" when \"GetSamplePoints\""));
        return;
    }

    // 获取 WidgetComponent 的组件变换
    FTransform WidgetComponentTransform = WidgetComponent->GetComponentTransform();

    // 使用变换矩阵的上方和左方向量
    FVector WidgetCenterWorldPosition = WidgetComponentTransform.TransformPosition(FVector(0.f, 0.f, 0.f));
    FVector upVector = WidgetComponentTransform.TransformPosition(FVector(0.f, 0.f, WidgetSize.Y / 2)) - WidgetCenterWorldPosition;
    FVector leftVector = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, 0.f)) - WidgetCenterWorldPosition;

    //**
    //FVector LeftUpLocation = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, WidgetSize.Y));
    //FVector RightVector = WidgetComponentTransform.TransformPosition(FVector(0.f, -WidgetSize.X / 2, WidgetSize.Y)) - LeftUpLocation;
    //FVector DownVector = WidgetComponentTransform.TransformPosition(FVector(0.f, WidgetSize.X / 2, 0)) - LeftUpLocation;
    //DownVector *= HeadRatio;
    //LeftUpLocation += Location;
    // UE_LOG(LogTemp, Warning, TEXT("%s, %s"), *leftVector.ToString(), *upVector.ToString());

    // 计算采样点的世界坐标
    // 左上角
    //FVector LeftUpLocation = Location + leftVector + upVector*2;
    FVector LeftUpLocation = TempBox[0];
    // 采样点矩阵的列数
    int Columns = 5;
    // 采样点矩阵的列数
    int Lines = 5;
    for (int i = 0; i < Columns; i++) {
        for (int j = 0; j < Lines; j++) {
            //SamplePoints[i * Lines + j] = LeftUpLocation - (2.f * leftVector * ((float)i / (Columns - 1))) - (2.f * upVector*HeadRatio * ((float)j / (Lines - 1)));
            SamplePoints[i * Lines + j] = LeftUpLocation + (TempBox[1] * ((float)i / (Columns - 1))) + (TempBox[2] * ((float)j / (Lines - 1)));
        }
    }
    //for (int i = 0; i < Columns; i++) {
    //    for (int j = 0; j < Lines; j++) {
    //        SamplePoints[i * Lines + j] = LeftUpLocation + (2.f * RightVector * ((float)i / (Columns - 1))) + (2.f * DownVector * ((float)j / (Lines - 1)));
    //    }
    //}
}

float AVisualizationTagView::DeterminantFor3x3(FVector a, FVector b, FVector c)
{
    float part1 = a.X * b.Y * c.Z - a.X * c.Y * b.Z;
    float part2 = b.X * c.Y * a.Z - b.X * a.Y * c.Z;
    float part3 = c.X * a.Y * b.Z - c.X * b.Y * a.Z;
    return part1 + part2 + part3;
}

float AVisualizationTagView::UpdateOcclusionRate(FVector ViewPosition, FVector UserPosition, TArray<AVisualizationTagView*> ViewBox, float MaxViewDistance)
{
    // 检查每个点的遮挡情况
    GetSamplePoints(ViewPosition);

    float OcclusionScore = 0.0f;

    PreferMoveDircetion = FVector(0.f, 0.f, 0.f);
    for (int i = 0; i < SamplePoints.Num(); i++)
    {
        if (PerformSingleRaycast(UserPosition, SamplePoints[i], ViewBox, MaxViewDistance))
        {
            // 倾向于向被遮挡点相对的方向移动
            PreferMoveDircetion += (ViewPosition - SamplePoints[i]).GetSafeNormal();
            OcclusionScore += 1.f;
        }
    }

    PreferMoveDircetion = PreferMoveDircetion.GetSafeNormal();

    // 归一化遮挡分数
    float MaxScore = SamplePoints.Num();
    OcclusionRate = OcclusionScore / MaxScore;

    // 如果被全遮挡，默认向上移动
    if (OcclusionRate == 1.f) {
        PreferMoveDircetion = FVector(0.f, 0.f, 1.f);
    }

    if (OcclusionRate > 0)
    {
        IsOccluded = true;
    }
    else
    {
        IsOccluded = false;
    }

     UE_LOG(LogTemp, Warning, TEXT("%s: %f"), *(ViewActor->GetName()), OcclusionRate);

    return OcclusionRate;
}

